# example

```
archives/example
archives/example/README.md
archives/example/dir
archives/example/dir/symlink
archives/example/dir/image.png
```
